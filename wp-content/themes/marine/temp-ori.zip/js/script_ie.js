
jQuery(document).ready(function($){
	
	/* IE PlaceHolder Fix */
	$('input, textarea').placeholder();

});