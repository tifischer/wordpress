<?php
/**
 * The Sidebar containing the left widget areas.
 *
 * @package marine
 * @since marine 1.0
 */
?>
<!-- Sidebar -->
<section class="sidebar col-lg-3 col-md-3 col-sm-4 small-padding">
	<?php dynamic_sidebar('shop' ); ?>
</section>
<!-- /Sidebar -->